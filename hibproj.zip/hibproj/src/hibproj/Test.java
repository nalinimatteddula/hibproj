package hibproj;

//import org.hibernate.Session;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		
		Session session = sessionFactory.openSession();
		
		Product product1 = session.get(Product.class,2);
		
		session.close();
		
		sessionFactory.close();
		System.out.println(product1.getSupplier());
		
	}

}
